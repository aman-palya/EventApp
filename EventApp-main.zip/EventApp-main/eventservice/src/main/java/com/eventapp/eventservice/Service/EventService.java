package com.eventapp.eventservice.Service;


import com.eventapp.eventservice.Entity.AllEvents;
import com.eventapp.eventservice.Entity.Event;

public interface EventService {

    public AllEvents getAllEvents();
    public Event getById(Long id);
}
