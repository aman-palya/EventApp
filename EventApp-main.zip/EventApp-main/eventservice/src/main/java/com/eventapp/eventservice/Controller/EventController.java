package com.eventapp.eventservice.Controller;


import com.eventapp.eventservice.Entity.AllEvents;
import com.eventapp.eventservice.Service.EventService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("event/")
@CrossOrigin(origins = "*")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }


    @Operation(summary = "Get All Event From Third Party Api")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found Event",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = AllEvents.class)) }),
            @ApiResponse(responseCode = "404", description = "Event not found",
                    content = @Content) })
    @GetMapping("allEvents")
    public AllEvents fetchEvents(){
        return eventService.getAllEvents();
    }


    @Operation(summary = "Get Event By Event IdFrom Third Party Api")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found Event",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = AllEvents.class)) }),
            @ApiResponse(responseCode = "404", description = "Event not found",
                    content = @Content) })
    @GetMapping("getEventById/{id}")
    public Object fetchById(@PathVariable long id){

        return eventService.getById(id);
    }


}
