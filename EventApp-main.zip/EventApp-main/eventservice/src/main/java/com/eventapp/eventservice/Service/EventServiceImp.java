package com.eventapp.eventservice.Service;

import com.eventapp.eventservice.Entity.Event;
import com.eventapp.eventservice.Entity.AllEvents;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Service
public class EventServiceImp implements EventService {

        @Value("${event.client.id}")
        private String clientId;

        @Value("${event.api.url}")
        private String url;


     @Autowired
     RestTemplate restTemplate;

     @Override
        public AllEvents getAllEvents() {
            URI uri= UriComponentsBuilder.fromUriString(url).queryParam("client_id",clientId).build().toUri();
        ResponseEntity<AllEvents> obj=   restTemplate.getForEntity(uri, AllEvents.class);
            return obj.getBody();
        }

        @Override
    public Event getById(Long id) {
        URI uri= UriComponentsBuilder.fromUriString(url+"/"+id).queryParam("client_id",clientId).build().toUri();
        ResponseEntity<Event> obj=   restTemplate.getForEntity(uri,Event.class);
        if(obj.getBody()!=null){
            return obj.getBody();
        }else {
            throw new ResourceNotFoundException("Resource Not Found");
        }
    }
}
