package com.eventapp.eventservice.Entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


@Data
public class Event {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("type")
    private String type;
    @JsonProperty("datetime_utc")
    private Date datetime_utc;
    @JsonProperty("venue")
    private Venue venue;
    @JsonProperty("performers")
    private List<Performers> performers;



}
