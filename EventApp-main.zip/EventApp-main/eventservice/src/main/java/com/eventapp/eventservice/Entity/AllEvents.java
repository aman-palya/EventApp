package com.eventapp.eventservice.Entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class AllEvents {

    @JsonProperty("events")
    private List<Event> events;
}
