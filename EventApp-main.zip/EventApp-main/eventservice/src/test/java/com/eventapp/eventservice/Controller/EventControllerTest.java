package com.eventapp.eventservice.Controller;

import com.eventapp.eventservice.Entity.AllEvents;
import com.eventapp.eventservice.Entity.Event;
import com.eventapp.eventservice.Service.EventService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class EventControllerTest {

    @Test
    void testFetchEvents() {
        EventService eventService = mock(EventService.class);
        EventController eventController = new EventController(eventService);

        Event resultEvent = new Event();
       // when(eventService.getAllEvents()).thenReturn(resultEvent);
        AllEvents fetchedEvent = eventController.fetchEvents();

        assertEquals(resultEvent, fetchedEvent);
    }

    @Test
    void testFetchById() {
        EventService eventService = mock(EventService.class);
        EventController eventController = new EventController(eventService);
        long eventId = 1L;

       // when(eventService.getById(eventId)).thenReturn(); // Adjust based on your return type
        Object result = eventController.fetchById(eventId);


        assertEquals("MockedEvent", result);
    }

}
