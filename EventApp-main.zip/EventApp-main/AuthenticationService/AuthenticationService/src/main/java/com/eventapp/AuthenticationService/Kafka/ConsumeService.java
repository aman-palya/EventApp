package com.eventapp.AuthenticationService.Kafka;

import com.eventapp.AuthenticationService.Model.UserCredentials;
import com.eventapp.AuthenticationService.Model.UserDetails;
import com.eventapp.AuthenticationService.Repository.UserRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumeService 
{
	 @Autowired
	 UserRepo userRepo;
	 private UserDetails fromPublisher;

	@KafkaListener(topics="EventApp", groupId="mygroup")

	public void consumeFromTopic(String message) throws JsonProcessingException {
		try {
			UserDetails userDetails=convertToJavaObject(message);
			userRepo.save(userDetails);
			System.out.println("--------------Consumer message--------: "+ userDetails.getUsername()+"---"
					+userDetails.getPassword());
		}
		catch (Exception e){
			System.out.println(e+"----Exception");
		}

	}

	private UserDetails convertToJavaObject(String message) throws JsonProcessingException {
		UserDetails userDetails=new ObjectMapper().readValue(message,UserDetails.class);
		System.out.println("from Converter"+userDetails+"-----");
		return  userDetails;
	}

	public UserDetails getkafkaMessage(){
		return  fromPublisher;
	}

}