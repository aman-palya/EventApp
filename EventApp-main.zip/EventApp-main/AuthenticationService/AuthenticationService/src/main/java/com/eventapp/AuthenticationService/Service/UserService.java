package com.eventapp.AuthenticationService.Service;


public interface UserService 
{

	public boolean loginUser(String username, String password);// login


	public String getRoleByUserAndPass(String username, String password);


	//ResponseEntity<?> UpdatePass(String email, String password, String confirmPassword, String answer, String question);
}
