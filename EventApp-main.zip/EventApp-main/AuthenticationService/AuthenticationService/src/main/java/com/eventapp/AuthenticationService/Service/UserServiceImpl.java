package com.eventapp.AuthenticationService.Service;


import com.eventapp.AuthenticationService.Model.UserCredentials;
import com.eventapp.AuthenticationService.Model.UserDetails;
import com.eventapp.AuthenticationService.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	UserRepo userRepo;

	@Override
	public boolean loginUser(String username, String password) {

		UserDetails user = userRepo.validateUser(username, password);
		if(user!=null)
		{
			System.out.println(username+"--service--"+password);
			return true;
		}

		return false;
	}

	@Override
	public String getRoleByUserAndPass(String username, String password) {

		String r=userRepo.GetRole(username, password);
		System.out.println(r+"role---");
		return r;
	}
}














