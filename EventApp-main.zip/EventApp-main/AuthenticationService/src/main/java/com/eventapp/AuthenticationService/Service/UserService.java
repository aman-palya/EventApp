package com.eventapp.AuthenticationService.Service;


import com.eventapp.AuthenticationService.Exception.UserNotFound;

public interface UserService
{

	public boolean loginUser(String username, String password) throws UserNotFound;// login


	public String getRoleByUserAndPass(String username, String password);


	//ResponseEntity<?> UpdatePass(String email, String password, String confirmPassword, String answer, String question);
}
