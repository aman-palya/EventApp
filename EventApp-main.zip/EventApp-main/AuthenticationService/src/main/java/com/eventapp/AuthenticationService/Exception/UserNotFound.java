package com.eventapp.AuthenticationService.Exception;

public class UserNotFound extends Exception {
    public UserNotFound(String sample_exception) {
        super(sample_exception);
    }
}