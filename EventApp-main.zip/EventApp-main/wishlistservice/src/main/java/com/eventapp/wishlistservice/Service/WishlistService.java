package com.eventapp.wishlistservice.Service;

import com.eventapp.wishlistservice.Entity.Events;
import com.eventapp.wishlistservice.Entity.Wishlist;

public interface WishlistService {

     Wishlist saveEventToWishlist(Long userId, Events event);

     Wishlist getWishlistEvents(Long userId);
     String deleteEventByUserIdAndEventId(Long userId, Long eventId);

     void addOrUpdateTrack(Wishlist wishList, Events newEvent);
}
