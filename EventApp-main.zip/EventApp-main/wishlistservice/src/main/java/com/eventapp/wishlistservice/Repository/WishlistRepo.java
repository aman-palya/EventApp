package com.eventapp.wishlistservice.Repository;

import com.eventapp.wishlistservice.Entity.Wishlist;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WishlistRepo extends MongoRepository<Wishlist,Long> {
}
