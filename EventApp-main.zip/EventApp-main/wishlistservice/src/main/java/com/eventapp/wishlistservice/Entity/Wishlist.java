package com.eventapp.wishlistservice.Entity;

import lombok.Data;

import org.springframework.data.mongodb.core.mapping.Document;


import java.util.List;
@Document
@Data
public class Wishlist {

    long id;
    List<Events> events;
}
