package com.eventapp.wishlistservice.Entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data

public class Venue {

    @JsonProperty("state")
    private String state;
    @JsonProperty("name")
    private String name;
    @JsonProperty("url")
    private  String url;
    @JsonProperty("address")
    private String address;
    @JsonProperty("country")
    private String country;
    @JsonProperty("has_upcoming_events")
    private String has_upcoming_events;
    @JsonProperty("city")
    private String city;

}
