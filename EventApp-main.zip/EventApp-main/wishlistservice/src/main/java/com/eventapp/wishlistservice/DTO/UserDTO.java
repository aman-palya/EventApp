package com.eventapp.wishlistservice.DTO;


import lombok.Data;

@Data
public class UserDTO {
}
