package com.eventapp.wishlistservice.Service;


import com.eventapp.wishlistservice.Entity.Events;
import com.eventapp.wishlistservice.Entity.Wishlist;
import com.eventapp.wishlistservice.Exception.ResourceNotFoundException;
import com.eventapp.wishlistservice.Repository.WishlistRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
    public  class WishlistServiceImp implements WishlistService{

        @Autowired
        WishlistRepo wishlistRepo;


        @Override
        public Wishlist saveEventToWishlist(Long userId, Events event) {
            Optional<Wishlist> wishListOptional = wishlistRepo.findById(userId);
//            Events events = modelMapper.map(trackDto, Track.class);
            Wishlist wishlist;
            if (wishListOptional.isPresent()) {
                // User's wish list exists, add or update the track
                wishlist = wishListOptional.get();
                addOrUpdateTrack(wishlist, event);
            } else {
                // User's wish list doesn't exist, create a new wish list
                wishlist = new Wishlist();
                wishlist.setId(userId);
                wishlist.setEvents(List.of(event));
            }

            // Save the updated wish list
            return wishlistRepo.save(wishlist);
        }
//
        @Override
        public Wishlist getWishlistEvents(Long userId) {
            // Implement logic to retrieve events saved in a user's wishlist
            Wishlist wishlist = wishlistRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User not found"));
            return wishlist;
        }

    @Override
    public String deleteEventByUserIdAndEventId(Long userId, Long eventId) {
         wishlistRepo.findById(userId).ifPresent(wishlist -> {
            // Find and remove the track with the specified id
             wishlist.getEvents().removeIf(events -> events.getId().equals(eventId));
             wishlistRepo.save(wishlist);
        });
        return "This EventId: "+eventId+" is deleted.";
    }


    @Override
    public void addOrUpdateTrack(Wishlist wishList, Events newEvent) {
        // Check if the track with the same ID already exists in the wish list
        boolean trackExists = wishList.getEvents().stream()
                .anyMatch(track -> track.getId().equals(newEvent.getId()));

        if (!trackExists) {
            // Track doesn't exist, add it to the wish list
            wishList.getEvents().add(newEvent);
        } else {
            // Track already exists, update it (if needed)
            wishList.getEvents().stream()
                    .filter(track -> track.getId().equals(newEvent.getId()))
                    .findFirst()
                    .ifPresent(existingTrack -> {
                        // Update track attributes if needed
                        existingTrack.setType(newEvent.getType());
                        existingTrack.setDate(newEvent.getDate());
                        existingTrack.setPerformers(newEvent.getPerformers());
                        existingTrack.setVenue(newEvent.getVenue());
                        // Update other attributes as needed
                    });
        }
    }
    }

