package com.eventapp.wishlistservice.Controller;

import com.eventapp.wishlistservice.Entity.Events;
import com.eventapp.wishlistservice.Service.WishlistService;
import com.eventapp.wishlistservice.Service.WishlistServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class WishlistController {

   @Autowired
    WishlistService wishlistService;

    @PostMapping("/wishlist/{userId}")
    public ResponseEntity<Void> saveEventToWishlist(@PathVariable Long userId, @RequestBody Events events) {
        wishlistService.saveEventToWishlist(userId, events);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/getWishlistById/{userId}")
    public ResponseEntity<Object> getWishlistEvents(@PathVariable Long userId) {
//       List<Event> wishlistEvents = wishlistService.getWishlistEvents(userId);
//        return ResponseEntity.ok(wishlistEvents);
        return new ResponseEntity<>(wishlistService.getWishlistEvents(userId), HttpStatus.OK);
    }

    @DeleteMapping("/remove-track/{userId}/{eventId}")
    public  ResponseEntity<Object> deleteEventFromWishlist(@RequestParam Long userId, @RequestParam Long eventId){
        return new ResponseEntity<>(wishlistService.deleteEventByUserIdAndEventId(userId, eventId),HttpStatus.OK);
    }
}

