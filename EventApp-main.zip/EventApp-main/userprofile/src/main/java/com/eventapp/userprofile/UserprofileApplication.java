package com.eventapp.userprofile;

import com.eventapp.userprofile.AOP.PerformanceTrackerHandler;
import com.eventapp.userprofile.Filter.JWTFilter;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.observation.aop.ObservedAspect;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class UserprofileApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserprofileApplication.class, args);
	}


	@Bean
	public FilterRegistrationBean jwtFilterBean()
	{
		FilterRegistrationBean fb = new FilterRegistrationBean();
		fb.setFilter(new JWTFilter());
		fb.addUrlPatterns("/api/v1.0/userProfile/getAllUser");
		fb.addUrlPatterns("/api/v1/getRole");
		return fb;

	}

	@Bean
	public ObservedAspect observedAspect(ObservationRegistry observationRegistry){
		observationRegistry.observationConfig().observationHandler(new PerformanceTrackerHandler());
		return new ObservedAspect(observationRegistry);
	}

}
