package com.eventapp.userprofile.Controller;

import com.eventapp.userprofile.DTO.UserDto;
//import com.eventapp.userprofile.Kafka.DataPublisherServiceImpl;

import com.eventapp.userprofile.Model.UserDetails;
import com.eventapp.userprofile.Model.UserProfile;

import com.eventapp.userprofile.Service.AuthService;
import com.eventapp.userprofile.Service.UserProfileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/api/v1.0/userProfile")
public class UserProfileController {

//    Logger logger = (Logger) LoggerFactory.getLogger(UserProfileController.class);

    @Autowired
    UserProfileService userProfileService;

    @Autowired
    AuthService authService;


//    @Autowired
//    DataPublisherServiceImpl producer;


    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Admin Access Get Users Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User Details Found",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = UserDto.class)) }),
            @ApiResponse(responseCode = "404", description = "User not found",
                    content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized user",
                    content = @Content) })
    @GetMapping("/getAllUser")
    public ResponseEntity<Object> getAllUsers(@RequestHeader("Authorization") String token){
        System.out.println(token+"from front end");
        log.info(token+" : token from authentication to access get all users");
        Map<String,String> info= authService.validateToken(token);
        System.out.println(info+"------"+token+"inside method get all-----");
        if(info.containsValue("Admin")) {
            System.out.println(token+"inside method get all-----__---");
            return new ResponseEntity<>(userProfileService.getAllUsers(), HttpStatus.OK);
        }
        return new ResponseEntity<>("UnAuthorized User", HttpStatus.UNAUTHORIZED);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Get Users Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User Details Found",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = UserDto.class)) }),
            @ApiResponse(responseCode = "404", description = "User not found",
                    content = @Content),
            @ApiResponse(responseCode = "401", description = "Unauthorized user",
                    content = @Content) })
    @GetMapping("getUserById/{id}")
    public ResponseEntity<Object> getUserProfileById(@PathVariable long id){
            return new ResponseEntity<>(userProfileService.getUserProfileById(id),HttpStatus.OK);
    }

    @Operation(summary = "Save User's Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "User Details Saved",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = UserDto.class)) }),
            @ApiResponse(responseCode = "409", description = "User Details already Exists",
                    content = @Content) })
    @PostMapping("/addUser")
    public ResponseEntity<Object> saveUserProfile(@RequestBody UserProfile userProfile){
        UserDetails userDetails=new UserDetails();
       // i will do this part later
     //   BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    //    String encodedPassword = encoder.encode(userProfile.getPassword());
        // log.info(encoder.matches(userProfile.getPassword(), encodedPassword)+"");

        userDetails.setUsername(userProfile.getUsername());
        userDetails.setPassword(userProfile.getPassword());
        userDetails.setRole("User");
        System.out.println("------"+userDetails+"--------");
//        producer.sendMessage(userDetails);
            return new ResponseEntity<>(userProfileService.saveUserProfile(userProfile),HttpStatus.OK);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Object> updateUserProfile(@RequestBody UserDto userDto, @PathVariable long id){
            return new ResponseEntity<>(userProfileService.updateUserProfile(userDto, id),HttpStatus.OK);
    }


    //method validation only for Admin
//    @DeleteMapping("/delete/{username}")
//    public ResponseEntity<?> deleteUserById(@RequestHeader("Authorization") String token,@PathVariable("username") String username)
//    {
//        System.out.println(token+"from front end");
//        Map<String,String> info= authService.validateToken(token);
//        if(info.containsValue("admin")){
//            if(userProfileService.deleteuser(username)){
//                return new ResponseEntity<>(HttpStatus.OK);
//            }
//            return new ResponseEntity<>("User isn't present in database",HttpStatus.BAD_REQUEST);
//        }
//        return new ResponseEntity<String>("User could not be deleted", HttpStatus.INTERNAL_SERVER_ERROR);
//    }

}
