package com.eventapp.userprofile.Service;


import com.eventapp.userprofile.DTO.UserDto;
import com.eventapp.userprofile.Model.UserProfile;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface UserProfileService {
    List<UserDto> getAllUsers();

    UserDto getUserProfileById(long id);

    UserDto saveUserProfile(UserProfile userProfile);

    UserDto updateUserProfile(UserDto userProfileDto, long id);

   // ResponseEntity<?> UpdatePass(String email, String password, String confirmPassword, String answer, String question);
   // boolean deleteuser(String username);
}
