package com.eventapp.userprofile.Service;
import com.eventapp.userprofile.DTO.UserDto;
import com.eventapp.userprofile.Exception.ResourceAlreadyExistsException;
import com.eventapp.userprofile.Model.UserProfile;
import com.eventapp.userprofile.Repository.UserProfileRepository;
import io.micrometer.observation.annotation.Observed;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class UserProfileServiceImpl implements UserProfileService {

    private final UserProfileRepository usersProfileRepository;

    private final ModelMapper modelMapper;

    @Autowired
    public UserProfileServiceImpl(UserProfileRepository usersProfileRepository, ModelMapper modelMapper) {
        this.usersProfileRepository = usersProfileRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public List<UserDto> getAllUsers() {

        return Stream.of(usersProfileRepository.findAll())
                .flatMap(entityList -> entityList.stream()
                        .map(entity -> modelMapper.map(entity, UserDto.class))).toList();

    }

    @Override
    @Observed(name = "get.user.profile.by.id")
    public UserDto getUserProfileById(long id) {
        UserProfile entity = usersProfileRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Entity not found with ID: " + id));

        return modelMapper.map(entity, UserDto.class);
    }

    @Override
    public UserDto saveUserProfile(UserProfile userProfile) {

        if (usersProfileRepository.existsByUsername(userProfile.getUsername()) || usersProfileRepository.existsByEmail(userProfile.getEmail())){
           throw new ResourceAlreadyExistsException("Try with another username this username is already present");
        }
        userProfile.setRole("User");
        return modelMapper.map(usersProfileRepository.save(userProfile), UserDto.class);
    }

    @Override
    public UserDto updateUserProfile(UserDto userProfileDto, long id) {
        UserProfile entity = usersProfileRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Entity not found with ID: " + id)
                       );

        entity.setEmail(userProfileDto.getEmail());
        entity.setFirstName(userProfileDto.getFirstName());
        entity.setLastName(userProfileDto.getLastName());
        entity.setNumber(userProfileDto.getNumber());

        usersProfileRepository.save(entity);

        return modelMapper.map(entity, UserDto.class);
    }

//    @Override
//    public ResponseEntity<?> UpdatePass(String email, String password, String confirmPassword, String answer, String question) {
//
//        if(usersProfileRepository.existsByEmail(email)){
//            System.out.println(email+password+confirmPassword+question+answer+"from inside service");
//            Optional<UserProfile> userdata = usersProfileRepository.findByEmail(email);
//            if(userdata.get().getQuestion().equals(question)){
//                if(userdata.get().getAnswer().equals(answer)){
//                    usersProfileRepository.updatePass(password,confirmPassword,email);
//                    return new ResponseEntity<>(HttpStatus.OK);
//                }
//                return new ResponseEntity<>("wrong answer",HttpStatus.FORBIDDEN);
//            }
//            return new ResponseEntity<>("question wrong",HttpStatus.BAD_REQUEST);
//
//        }
//        return new ResponseEntity<>("user doesn't exist",HttpStatus.NOT_FOUND);
//    }

 //   @Override
//    public boolean deleteuser(String username) {
//        Optional<UserProfile> obj= usersProfileRepository.findByName(username);
//        if(obj.isPresent()){
//            System.out.println(obj+"from db");
//            usersProfileRepository.deleteByUsername(username);
//            return true;
//        }
//        return false;
//
//    }

}
