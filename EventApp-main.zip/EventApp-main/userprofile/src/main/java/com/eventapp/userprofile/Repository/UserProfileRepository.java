package com.eventapp.userprofile.Repository;


import com.eventapp.userprofile.Model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

  //  @Query(value = "select * from user where email=?1",nativeQuery = true)
  //  Optional<UserProfile> findByEmail(String email);


//    @Modifying(clearAutomatically = true)
//    @Query(value = "UPDATE  User u SET u.password =?1,u.confirmPassword=?2 where u.email=?3")
//    void updatePass(String password, String confirmPassword,String email);
//

//    void deleteByUsername(String username);
//
//    Optional<UserProfile> findByName(String username);
}
