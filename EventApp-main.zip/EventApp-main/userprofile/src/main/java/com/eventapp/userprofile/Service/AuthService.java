package com.eventapp.userprofile.Service;


import com.eventapp.userprofile.Exception.ServerConnectionException;
import com.eventapp.userprofile.Exception.UnAuthorizedException;
import com.eventapp.userprofile.FeignClient.AuthenticationClient;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
@Slf4j
public class AuthService {
    @Autowired
    AuthenticationClient authenticationClient;

    public Map<String, String> validateToken(String token) {
        try {
            ResponseEntity<Map<String, String>> response = authenticationClient.validateToken(token);

            log.info(response.getBody()+"------from------");

            if (response.getStatusCode() == HttpStatus.OK) {
                return response.getBody();
            } else {
                throw new UnAuthorizedException("Failed to validate token: " + response.getStatusCode());
            }
        } catch (Exception e) {
            throw new ServerConnectionException("connection refused: " + e.getMessage());

        }
    }

}