package com.eventapp.userprofile.Kafka;
import com.eventapp.userprofile.Model.UserDetails;
import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

//@Service
//public class DataPublisherServiceImpl
//{
//	public static final String topic ="EventApp";
//
//	@Autowired
//	private KafkaTemplate<String, UserDetails> kafkaTemplate;
//
//	public void sendMessage(UserDetails user)
//	{
//		System.out.println(user);
//
//		kafkaTemplate.send(topic, user);
//	}
//
//}