package com.eventapp.userprofile.DTO;

import lombok.*;

import java.util.Date;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserDto {




        private long id;
        private String username;
        private String firstName;
        private String lastName;
        private String password;
        private long number;
        private String question;
        private String answer;
        private String email;

    }

